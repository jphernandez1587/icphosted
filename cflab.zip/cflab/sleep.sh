echo ""CONTENEDOR INICIADO! ABRA UNA NUEVA TERMINAL Y EJECUTE "docker exec -it <id contenedor> /bin/bash" para conectarse al contenedor
while true; do sleep 1; done
